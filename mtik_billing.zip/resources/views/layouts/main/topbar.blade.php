        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
          <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="navbar-nav ml-auto">


            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">

                  <div class="input-group">
                    <input name="query" type="text" class="form-control bg-light border-1 small" placeholder="Search users.."
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                
              </div>
            </li>
            <div class="topbar-divider d-none d-sm-block helpline-div"></div>
            <li class="nav-item no-arrow helpline-div">
              <a class="nav-link " href="#"  role="button">
                <i class="fas fa-tty"></i>&nbsp;&nbsp; <small>01740964485</small>
              </a>
            </li>
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="{{ asset('resources/assets/img/boy.png') }}" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small">{{Auth::user()->name}}</span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

				<a class="dropdown-item" href="#">                  
                  <strong>{{ucwords(Auth::user()->role->name)}}</strong>
                </a>
                
                <div class="dropdown-divider"></div>
                
                <a class="dropdown-item" href="#">
                  <i class="fas fa-info fa-sm fa-fw mr-2 text-gray-400"></i>
                  ID - {{Auth::user()->id}}
                </a>

                <div class="dropdown-divider"></div>

                <a class="dropdown-item" href="{{url('/change-password')}}">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Change Password
                </a>

                <div class="dropdown-divider logout-div"></div>
                <a class="dropdown-item logout-div" href="{{url('/logout')}}">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar -->