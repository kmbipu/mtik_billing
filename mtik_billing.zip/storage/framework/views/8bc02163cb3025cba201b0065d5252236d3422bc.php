<?php $__env->startSection('pageTitle', 'All Pools'); ?>

<?php $__env->startSection('headerRight'); ?>
<form class="form-inline auto-align" method="get" action="">

    <div class="md-form auto-align">
        <input name="query" class="form-control form-control-sm" type="text" placeholder="Search here" aria-label="Search" value="<?php echo e(request('query')); ?>">
    </div>
    <button href="#" class="btn btn-sm btn-primary auto-align" type="submit"><i class="fa fa-search"></i></button>
    <a class="btn btn-sm btn-primary auto-align" href="<?php echo e(url('admin/pools/add')); ?>"><i class="fas fa-plus"></i> Add New</a>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 mb-4">
        <!-- Simple Tables -->
        <div class="card">            
            <div class="table-responsive">
                <table class="table align-items-center table-flush table-td-sm">
                <thead class="thead-light">
                    <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>IP Range</th>
                    <th>Router</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                    <tr>
                    <td><?php echo e($d->id); ?></td>
                    <td><?php echo e($d->name); ?></td> 
                    <td><?php echo e($d->ip_range); ?></td> 
                    <td><?php echo e($d->router->name); ?></td> 
                    <td>
                        <a href="<?php echo e(url("/admin/pools/edit").'/'.$d->id); ?>" class="btn btn-sm btn-warning">Edit</a> 
                        <a d_id="<?php echo e($d->id); ?>" d_action="<?php echo e(url('/admin/pools/delete/'.$d->id)); ?>" href="#" class="btn btn-sm btn-danger delete-action-btn">Delete</a>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>           
            <div class="card-footer"></div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/pool/list.blade.php ENDPATH**/ ?>