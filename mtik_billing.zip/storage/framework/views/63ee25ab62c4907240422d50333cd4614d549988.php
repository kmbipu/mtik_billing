<?php $__env->startSection('pageTitle', 'Recharge History'); ?>

<?php $__env->startSection('headerRight'); ?>
<h5>Total - <?php echo e($total); ?></h5>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomScripts'); ?>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
      dateFormat: 'yy-mm-dd'
    });
  } );
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $admin = \app\Services\Helper::isAdmin(); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<div class="row">
    <div class="col-lg-12 mb-4">
        <!-- Simple Tables -->
        
        <form method="get">
            <div class="mb-4 row">
            	
            	<div class="col-sm-2">
                    <input name="start_date" class="datepicker form-control form-control-sm auto-align" type="text" placeholder="Start Date" aria-label="Search" value="<?php echo e(request('start_date')); ?>" autocomplete="off">
                </div>
                <div class="col-sm-2">
                    <input name="end_date" class="datepicker form-control form-control-sm auto-align" type="text" placeholder="End Date" aria-label="Search" value="<?php echo e(request('end_date')); ?>" autocomplete="off">
                </div>
                <?php if($admin): ?>
                <div class="col-sm-2">
                    <input name="seller_id" class="form-control form-control-sm auto-align" type="text" placeholder="Seller ID" aria-label="Search" value="<?php echo e(request('seller_id')); ?>">
                </div>
                <?php endif; ?>
                <div class="col-sm-3">
                    <input name="query" class="form-control form-control-sm auto-align" type="text" placeholder="ID,User,Method.." aria-label="Search" value="<?php echo e(request('query_str')); ?>">
                </div>
                 <div class="col-sm-3">
                     <button href="#" class="btn btn-sm btn-primary auto-align" type="submit"><i class="fa fa-search"></i> Search</button>
                     <a href="<?php echo e(url('admin/transactions/recharges')); ?>" class="btn btn-sm btn-default auto-align" >Reset</a>
                 </div>  
          
            </div>
        </form>
        <div class="card">            
            <div class="table-responsive">
                <table class="table align-items-center table-flush table-td-sm">
                <thead class="thead-light">
                    <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>User</th>
                    <th>Plan</th>
                    <th>Amount</th>     
                    <th>Method</th>                
                    <th>Status</th>
                    <?php if($admin): ?> 
                    <th>Action</th>
                    <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                    <tr>
                    <td><?php echo e($d->id); ?></td>
                    <td><?php echo e($d->created_at->format('Y-m-d')); ?></td> 
                    <td><?php echo e($d->username); ?></td> 
                    <td><?php echo e($d->plan_name); ?></td> 
                    <td><?php echo e($d->amount); ?></td>  
                    <td><?php echo e($d->p_method); ?></td>                                     
                    <?php if($d->status=='complete'): ?>
                    <td><span class="badge badge-success"><?php echo e($d->status); ?></span></td> 
                    <?php endif; ?>
                    <?php if($d->status=='pending'): ?>
                    <td><span class="badge badge-danger"><?php echo e($d->status); ?></span></td> 
                    <?php endif; ?>
                    <?php if($admin): ?>                  
                    <td>
                        <a href="<?php echo e(url("/admin/transactions/edit").'/'.$d->id); ?>" class="btn btn-sm btn-warning">Edit</a> 
                        <a d_id="<?php echo e($d->id); ?>" d_action="<?php echo e(url('/admin/transactions/delete/'.$d->id)); ?>" href="#" class="btn btn-sm btn-danger delete-action-btn">Delete</a>
                    </td>
                    <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
                
            </div>           
            <div class="card-footer"><?php echo e($data->appends(request()->all())->links('paginator')); ?></div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/transaction/recharge_list.blade.php ENDPATH**/ ?>