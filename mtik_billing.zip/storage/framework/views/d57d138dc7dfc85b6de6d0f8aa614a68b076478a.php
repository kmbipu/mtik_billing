 
<?php $__env->startSection('pageTitle', 'Welcome to S.Cable Network'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

	<style>
	header{
    	background-image: url(<?php echo e(url('public/images/home-banner.jpg')); ?>);
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
	}	
	</style>
	
	
    <!-- Jumbotron Header -->
    <header class="jumbotron my-4 text-right">
      <h3 class="display-3 text-white">S. Cable Network</h3>
      
      <a href="<?php echo e(url('/login')); ?>" class="btn btn-warning btn-lg">Login Here</a><br><br>
      <p><small class="text-white">For any inquiry - 01740964485</small></p>
    </header>

    <!-- Page Features -->
    <div class="row text-center">
	<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-3 col-md-6 mb-4">
        <div class="card">
          <img class="card-img-top" src="<?php echo e(url('public/images/package.png')); ?>" alt="">
          <div class="card-body">
            <h4 class="card-title"><?php echo e($plan->name); ?></h4>
            <p>Speed - <?php echo e($plan->bandwidth->rate_down.' '.$plan->bandwidth->rate_down_unit); ?></p>
            <p>For <?php echo e($plan->validity.' '.ucwords($plan->validity_unit)); ?></p>
            <button class="btn btn-danger btn-block">৳  <?php echo e($plan->price); ?></button>
          </div>
        </div>
      </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

    </div>
    <hr>
    <!-- /.row -->
    <div class="row">
    	<div class="col-sm-12 text-center">
    		Developed by <a href="http://www.codexwp.com">CodexWP</a>
    	</div>
    </div>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/page/home.blade.php ENDPATH**/ ?>