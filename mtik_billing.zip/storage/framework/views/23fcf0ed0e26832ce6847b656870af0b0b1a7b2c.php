<?php $__env->startSection('pageTitle', 'All PPPoe Users'); ?>

<?php $__env->startSection('headerRight'); ?>
<?php $admin = \app\Services\Helper::isAdmin(); ?>
<form class="form-inline" method="get" action="">
	<?php if($admin): ?>
	<div class="md-form my-0 mr-2">
        <select id="User Type" name="created_by" class="form-control form-control-sm">
            <option value="">Select Seller</option>
            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            	<option value="<?php echo e($r->id); ?>" <?php echo e(request('created_by')==$r->id?'selected':''); ?>><?php echo e($r->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php endif; ?>
    <div class="md-form auto-align">
        <select id="User Type" name="plan_id" class="form-control form-control-sm">
            <option value="">All Plans</option>
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            	<option value="<?php echo e($p->id); ?>" <?php echo e(request('plan_id')==$p->id?'selected':''); ?>><?php echo e($p->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="md-form auto-align">
        <input  name="query" class="form-control form-control-sm" type="text" placeholder="Search name, user, id" aria-label="Search" value="<?php echo e(request('query')); ?>">
    </div>
    <button href="#" class="btn btn-sm btn-primary auto-align" type="submit"><i class="fa fa-search"></i></button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 mb-4">
        <!-- Simple Tables -->
        <div class="card">            
            <div class="table-responsive">
                <table class="table align-items-center table-flush table-td-sm">
                <thead class="thead-light">
                    <tr>
                    <th>User</th>
                    <th>Plan</th>    
                    <th>Start</th>   
                    <th>Expire</th>
                    <th>Seller</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                    <tr>
                    <td style="color:<?php echo e($d->status?'green':'red'); ?>"><?php echo e($d->username); ?></td> 
                    <td><?php echo e(\app\Services\PlanService::find($d->plan_id)->name); ?></td>   
                    <td><?php echo e($d->start_dt); ?></td>                
                    <td style="color:<?php echo e(date('Y-m-d') > $d->expire_dt?'red':''); ?>"><?php echo e($d->expire_dt); ?></td>
                    <td><?php echo e($d->created_by); ?></td>                    
                    <td>
                    	<a href="<?php echo e(url("/admin/prepaids/renew").'/'.$d->id); ?>" class="btn btn-sm btn-info">Renew</a>
                    	
                    	<?php if($admin): ?>
                         <a href="<?php echo e(url("/admin/prepaids/edit").'/'.$d->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                         <a d_id="<?php echo e($d->id); ?>" d_action="<?php echo e(url('/admin/prepaids/delete/'.$d->id)); ?>" href="#" class="btn btn-sm btn-danger delete-action-btn">Delete</a>
                    	<?php endif; ?>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>           
            <div class="card-footer"><?php echo e($data->appends(request()->all())->links('paginator')); ?></div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/prepaid/list.blade.php ENDPATH**/ ?>