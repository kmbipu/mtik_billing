<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php $version = env('APP_VERSION'); ?>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="site-url" content="<?php echo e(url('/')); ?>">
  <meta name="current-url" content="<?php echo e(url(request()->path())); ?>">
  <link href="<?php echo e(asset('resources/assets/img/logo/logo.png')); ?>" rel="icon">
  <title><?php echo $__env->yieldContent('pageTitle'); ?> - SCable.Net</title>
  <link href="<?php echo e(asset('resources/assets/vendor/fontawesome-free/css/all.min.css')); ?>?ver=<?php echo e($version); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('resources/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>?ver=<?php echo e($version); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('resources/assets/css/theme.css')); ?>?ver=<?php echo e($version); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('resources/assets/css/main.css')); ?>?ver=<?php echo e($version); ?>" rel="stylesheet">
  <script src="<?php echo e(asset('resources/assets/vendor/jquery/jquery.min.js')); ?>?ver=<?php echo e($version); ?>"></script>
  <?php echo $__env->yieldContent('topScripts'); ?>
</head>

<body id="page-top"><?php /**PATH /var/www/html/mtik_billing/resources/views/layouts/main/head.blade.php ENDPATH**/ ?>