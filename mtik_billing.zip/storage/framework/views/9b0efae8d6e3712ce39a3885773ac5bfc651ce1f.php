 
<?php $__env->startSection('pageTitle', 'Edit Plan : '.$data->id); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col-md-6 mb-4">
			<!-- Simple Tables -->
			<div class="card">

				<div class="card-body">
					<div class="form-group">
						<label>Plan Name</label> 
						<input value="<?php echo e($data->name); ?>" name="name" type="text"
							class="form-control" placeholder="Enter plan name" required readonly>
					</div>

					<div class="form-group">
						<label for="exampleFormControlSelect1">Router</label> <select
							class="form-control" name="router_id" required>
							<option value="">Select Router</option> <?php $__currentLoopData = $routers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $router): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($router->id); ?>" <?php echo e($data->router_id==$router->id?'selected':''); ?>><?php echo e($router->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
						<label for="exampleFormControlSelect1">Pool</label> <select
							class="form-control" name="pool_id" required>
							<option value="">Select Pool</option> <?php $__currentLoopData = $pools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($pool->id); ?>" <?php echo e($pool->id==$data->pool_id?'selected':''); ?>><?php echo e($pool->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

					<div class="form-group">
						<label for="exampleFormControlSelect1">Bandwidth</label> <select
							class="form-control" name="bandwidth_id" required>
							<option value="">Select Bandwidth</option> <?php $__currentLoopData = $bws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($bw->id); ?>" <?php echo e($bw->id==$data->bandwidth_id?'selected':''); ?>><?php echo e($bw->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					
					<div class="form-group">
						<label for="exampleFormControlSelect1">Seller</label> 
						<select	class="form-control" name="seller_id" required>
							<?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($seller->id); ?>" <?php echo e($seller->id==$data->seller_id?'selected':''); ?>><?php echo e($seller->id); ?>-<?php echo e($seller->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					
					<div class="form-group">
						<div class="row">
							<div class="col-sm-8">
    							<label>Validity</label> <input value="<?php echo e($data->validity); ?>" name="validity" type="number"
    							class="form-control" placeholder="Enter validity" required>
							</div>
							<div class="col-sm-4">
								<label>Unit</label> 
								<select	class="form-control" name="validity_unit" required>
									<option value="days" <?php echo e($data->validity_unit=='days'?'selected':''); ?>>Days</option>
									<option value="month" <?php echo e($data->validity_unit=='month'?'selected':''); ?>>Month</option>
								</select>
							</div>
						</div>
					</div>
					
				</div>

			</div>
		</div>
		<div class="col-md-6 mb-4">
			<!-- Simple Tables -->
			<div class="card">

				<div class="card-body">					
					
					<div class="form-group">
						<label>Price</label> <input value="<?php echo e($data->price); ?>" name="price" type="number"
							class="form-control" placeholder="Enter price" required>
					</div>
					
					<div class="form-group">
						<label>Discount</label> <input value="<?php echo e($data->discount); ?>" name="discount" type="number"
							class="form-control" placeholder="Enter discount(optional)">
					</div>
					
					<div class="form-group">
						<label for="exampleFormControlSelect1">Active/Inactive</label> 
						<select	class="form-control" name="is_active">
							<option value="1" <?php echo e($data->is_active=='1'?'selected':''); ?>>Yes</option> 
							<option value="0" <?php echo e($data->is_active=='0'?'selected':''); ?>>No</option> 
						</select>
					</div>
					
					<div class="form-group">
						<label for="exampleFormControlSelect1">Home Display</label> 
						<select	class="form-control" name="is_display">
							<option value="1" <?php echo e($data->is_display=='1'?'selected':''); ?>>Yes</option> 
							<option value="0" <?php echo e($data->is_display=='0'?'selected':''); ?>>No</option> 
						</select>
					</div>

					<br>
					<div class="form-group text-center">
						<button type="submit" class="btn btn-primary pull-right mr-3">Update</button>
						<a href="<?php echo e(url('admin/plans')); ?>"
							class="btn btn-default pull-right">Back</a>
					</div>

				</div>

			</div>
		</div>
	</div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/plan/edit.blade.php ENDPATH**/ ?>