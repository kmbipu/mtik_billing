 <?php $__env->startSection('pageTitle', 'Edit Role : '.$role->id); ?>

<?php $__env->startSection('headerRight'); ?>
<a class="btn btn-sm btn-primary btn-md my-0 ml-sm-2"
	href="<?php echo e(url('admin/roles')); ?>"><i class="fas fa-bars"></i> List</a>
<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6 mb-4">
		<!-- Simple Tables -->
		<div class="card">
			<div class="card-body">
				<form method="post">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<label for="input_role_name">Name</label> <input name="name"
							type="text" class="form-control" placeholder="Enter a role name"
							value="<?php echo e($role->name); ?>" required>
					</div>
					<div class="form-group">
							
						<label for="exampleFormControlSelect1">Prefix</label>
                        <select class="form-control"  name="prefix" required>
                        <option value="">Select Prefix</option>
                        <option value="admin" <?php echo e($role->prefix=='admin'?'selected':''); ?>>Admin</option>
                        <option value="customer" <?php echo e($role->prefix=='customer'?'selected':''); ?>>Customer</option>
                        </select>
					</div>
					
					<button type="submit" class="btn btn-primary">Update</button>
					<a href="<?php echo e(url("admin/roles")); ?>" class="btn btn-default">Back</a>
				</form>
			</div>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/role/edit.blade.php ENDPATH**/ ?>