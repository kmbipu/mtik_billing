<?php $__env->startSection('pageTitle', 'My Customers'); ?>

<?php $__env->startSection('headerRight'); ?>
<form class="form-inline " method="get" action="">
	<div class="md-form auto-align">
        <input name="created_by" class="form-control form-control-sm" type="text" placeholder="Created By ID" aria-label="Search" value="<?php echo e(request('created_by')); ?>">
    </div>
    <div class="md-form auto-align">
        <input name="query" class="form-control form-control-sm" type="text" placeholder="Search name, user, phone" aria-label="Search" value="<?php echo e(request('query')); ?>">
    </div>
    <button href="#" class="btn btn-sm btn-primary auto-align" type="submit"><i class="fa fa-search"></i></button>
    <a class="btn btn-sm btn-primary auto-align" href="<?php echo e(url('reseller/users/customers/add')); ?>"><i class="fas fa-plus"></i> Add New</a>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 mb-4">
        <!-- Simple Tables -->
        <div class="card">            
            <div class="table-responsive">
                <table class="table align-items-center table-flush table-td-sm">
                <thead class="thead-light">
                    <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>User</th>
                    <th>Phone</th>
                    <th>Seller</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                    <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td> 
                    <td><?php echo e($user->username); ?></td> 
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->created_by); ?></td>                 
                    <td>
                        <a href="<?php echo e(url("/reseller/users/edit").'/'.$user->id); ?>" class="btn btn-sm btn-warning">Edit</a> 
                        <a d_id="<?php echo e($user->id); ?>" d_action="<?php echo e(url('/reseller/users/delete/'.$user->id)); ?>" href="#" class="btn btn-sm btn-danger delete-action-btn">Delete</a>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>           
            <div class="card-footer"><?php echo e($users->appends(request()->all())->links('paginator')); ?></div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/reseller/user/customer_list.blade.php ENDPATH**/ ?>