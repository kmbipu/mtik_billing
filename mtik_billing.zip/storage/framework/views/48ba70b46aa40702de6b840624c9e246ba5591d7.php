<?php $__env->startSection('pageTitle', 'Add Customer'); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
	<input type="hidden" name="role_id" value="<?php echo e($role->id); ?>">
  <?php echo csrf_field(); ?>
  <div class="row">
      <div class="col-md-6 mb-4">
          <!-- Simple Tables -->
          <div class="card"> 
              <div class="card-header">User Info</div>           
              <div class="card-body">                  
                    <div class="form-group">
                      <label>Name</label>
                      <input value="<?php echo e(request('name')); ?>" name="name" type="text" class="form-control" placeholder="Enter fullname" required>
                    </div>
                    <div class="form-group">
                      <label>Username</label>
                      <input value="<?php echo e(request('username')); ?>" name="username" type="text" class="form-control" placeholder="Enter username" required>
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input value="<?php echo e(request('password')); ?>" name="password" type="password" class="form-control" placeholder="Enter password" required>
                    </div>
                    <div class="form-group">
                      <label>Confirm Password</label>
                      <input value="<?php echo e(request('password_confirmation')); ?>" name="password_confirmation" type="password" class="form-control" placeholder="Enter password" required>
                    </div>
              </div>         
              
          </div>
      </div>

      <div class="col-md-6 mb-4">
          <!-- Simple Tables -->
          <div class="card">            
          <div class="card-header">Profile Info</div>           
              <div class="card-body">                  
                    <div class="form-group">
                      <label>Phone</label>
                      <input value="<?php echo e(request('phone')); ?>"  name="phone" type="text" class="form-control" placeholder="Enter phone no" required>
                    </div>
                    <div class="form-group">
                      <label>Address</label>
                      <input value="<?php echo e(request('address')); ?>" name="address" type="text" class="form-control" placeholder="Enter address" required>
                    </div>
                    <div class="form-group">
                      <label>NID</label>
                      <input value="<?php echo e(request('nid')); ?>" name="nid" type="text" class="form-control" placeholder="Enter NID number" required>
                    </div>
                    <br>
                    <div class="form-group text-center">
                      <button type="submit" class="btn btn-primary pull-right mr-3">Create</button>
                      <a href="<?php echo e(url('reseller/users/'.$role->slug.'s')); ?>" class="btn btn-default pull-right">Back</a>
                    </div>
                    
              </div>        
              
          </div>
      </div>    
  </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/reseller/user/add_customer.blade.php ENDPATH**/ ?>