<?php $__env->startSection('pageTitle', 'Add Pool'); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
  <?php echo csrf_field(); ?>
  <div class="row">
      <div class="col-md-6 mb-4">
          <!-- Simple Tables -->
          <div class="card">           
        
              <div class="card-body">                  
                    <div class="form-group">
                      <label>Name</label>
                      <input value="<?php echo e(request('name')); ?>" name="name" type="text" class="form-control" placeholder="Enter pool name" required>
                    </div>
                    <div class="form-group">
                      <label>IP Range</label>
                      <input value="<?php echo e(request('ip_range')); ?>" name="ip_range" type="text" class="form-control" placeholder="Enter IP range" required>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Router</label>
                        <select class="form-control"  name="router_id" required>
                        <option value="">Select Router</option>
                        <?php $__currentLoopData = $routers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $router): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($router->id); ?>" <?php echo e(request('router_id')==$router->id?'selected':''); ?>><?php echo e($router->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <br>
                    <div class="form-group text-center">
                      <button type="submit" class="btn btn-primary pull-right mr-3">Create</button>
                      <a href="<?php echo e(url('admin/pools')); ?>" class="btn btn-default pull-right">Back</a>
                    </div>
                    
              </div>        
              
          </div>
      </div>    
  </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/pool/add.blade.php ENDPATH**/ ?>