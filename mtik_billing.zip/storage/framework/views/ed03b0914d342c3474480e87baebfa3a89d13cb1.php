<?php $__env->startSection('pageTitle', 'All Plans'); ?>

<?php $__env->startSection('headerRight'); ?>
<?php $admin = \app\Services\Helper::isAdmin(); ?>
<form class="form-inline" method="get" action="">
	<?php if($admin): ?>
	<div class="md-form auto-align">
        <select id="User Type" name="seller_id" class="form-control form-control-sm">
            <option value="">Select Seller</option>
            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            	<option value="<?php echo e($r->id); ?>" <?php echo e(request('seller_id')==$r->id?'selected':''); ?>><?php echo e($r->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php endif; ?>
    <div class="md-form auto-align">
        <input name="query" class="form-control form-control-sm" type="text" placeholder="Search name" aria-label="Search" value="<?php echo e(request('query')); ?>">
    </div>
    <button href="#" class="btn btn-sm btn-primary auto-align" type="submit"><i class="fa fa-search"></i></button>
    <a class="btn btn-sm btn-primary auto-align" href="<?php echo e(url('admin/plans/add')); ?>"><i class="fas fa-plus"></i> Add New</a>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 mb-4">
        <!-- Simple Tables -->
        <div class="card">            
            <div class="table-responsive">
                <table class="table align-items-center table-flush table-td-sm">
                <thead class="thead-light">
                    <tr>
                    <th>ID</th>
                    <th>Name</th>                    
                    <th>Bandwidth</th>
                    <th>Price</th>
                    <th>Discount</th>
                    <?php if($admin): ?>
                    <th>Seller</th>
                    <th>Display</th>
                    <th>Action</th>
                    <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                    <tr>
                    <td><?php echo e($d->id); ?></td>
                    <td style="color:<?php echo e($d->is_active?'':'red'); ?>"><?php echo e($d->name); ?></td> 
                    <td><?php echo e($d->bandwidth->name); ?></td>
                    <td><?php echo e($d->price); ?></td>
                    <td><?php echo e($d->discount); ?></td>
                    <?php if($admin): ?>
                    <td><?php echo e($d->seller_id); ?></td> 
                    <td><?php echo e($d->is_display); ?></td> 
                    <td>
                        <a href="<?php echo e(url("/admin/plans/edit").'/'.$d->id); ?>" class="btn btn-sm btn-warning">Edit</a> 
                        <a d_id="<?php echo e($d->id); ?>" d_action="<?php echo e(url('/admin/plans/delete/'.$d->id)); ?>" href="#" class="btn btn-sm btn-danger delete-action-btn">Delete</a>
                    </td>
                    <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>           
            <div class="card-footer"><?php echo e($data->appends(request()->all())->links('paginator')); ?></div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/plan/list.blade.php ENDPATH**/ ?>