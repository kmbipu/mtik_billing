 
<?php $__env->startSection('pageTitle', 'Fund Transfer Review'); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
<?php echo csrf_field(); ?>
	<input type="hidden" name="action" value="transfer">
	
	<input type="hidden" name="type" value="transfer">	
	<input type="hidden" name="user_id" value="<?php echo e($data->user_id); ?>">
	<input type="hidden" name="username" value="<?php echo e($data->username); ?>">
	<input type="hidden" name="status" value="complete">
	<input type="hidden" name="amount" value="<?php echo e($data->amount); ?>">
	<input type="hidden" name="p_method" value="<?php echo e($data->p_method); ?>">
	<input type="hidden" name="p_trxid" value="<?php echo e($data->p_trxid); ?>">
	<input type="hidden" name="p_notes" value="<?php echo e($data->p_notes); ?>">

	
	<div class="row">
		<div class="col-md-6 mb-4">
			<!-- Simple Tables -->
			<div class="card">
				<div class="card-header">
					Account & Plan
				</div>

				<div class="card-body">					
					
					
					<div class="table-responsive">
                        <table class="table table-td-sm table-bordered">  
                            <tbody>
                            	<tr><td>Name</td><td><?php echo e($data->name); ?></td><tr>
                            	<tr><td>Username</td><td><?php echo e($data->username); ?></td><tr>
                            	<tr><td>Amount</td><td><?php echo e($data->amount); ?></td><tr>
                            	<tr><td>Method</td><td><?php echo e($data->p_method); ?></td><tr>
                            	<tr><td>Trx. ID</td><td><?php echo e($data->p_trxid); ?></td><tr>
                            	<tr><td>Notes</td><td><?php echo e($data->p_notes); ?></td><tr>
                            </tbody>
                        </table>
                        <br>
                        <br>
                        
                        
                        <div class="form-group text-center">
                          <button type="submit" class="btn btn-primary pull-right mr-3">Confirm Transfer</button>
                        </div>
                        
                        
                    </div>						

				</div>

			</div>
		</div>
		
	</div>
</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/transaction/transfer_review.blade.php ENDPATH**/ ?>