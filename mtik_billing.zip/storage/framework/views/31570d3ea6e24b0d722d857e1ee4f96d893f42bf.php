<?php $__env->startSection('pageTitle', 'Edit Router : '.$router->id); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
  <?php echo csrf_field(); ?>
  <div class="row">
      <div class="col-md-6 mb-4">
          <!-- Simple Tables -->
          <div class="card">           
        
              <div class="card-body">                  
                    <div class="form-group">
                      <label>Name</label>
                      <input value="<?php echo e($router->name); ?>" name="name" type="text" class="form-control" placeholder="Enter router name" required>
                    </div>
                    <div class="form-group">
                      <label>IP Address</label>
                      <input value="<?php echo e($router->ip); ?>" name="ip" type="text" class="form-control" placeholder="Enter ip address" required>
                    </div>
                    <div class="form-group">
                      <label>Username</label>
                      <input value="<?php echo e($router->username); ?>" name="username" type="text" class="form-control" placeholder="Enter username" required>
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input value="<?php echo e($router->password); ?>" name="password" type="text" class="form-control" placeholder="Enter password" required>
                    </div>
                    <div class="form-group">
                      <label>Details</label>
                      <textarea  name="details" class="form-control" placeholder="Enter Details (optional)"><?php echo e($router->details); ?></textarea>
                    </div>
                    <br>
                    <div class="form-group text-center">
                      <button type="submit" class="btn btn-primary pull-right mr-3">Update</button>
                      <a href="<?php echo e(url('admin/routers')); ?>" class="btn btn-default pull-right">Back</a>
                    </div>
                    
              </div>        
              
          </div>
      </div>    
  </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/router/edit.blade.php ENDPATH**/ ?>