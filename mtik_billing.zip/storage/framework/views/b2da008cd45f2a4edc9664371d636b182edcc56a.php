<?php $__env->startSection('pageTitle', 'Add Bandwidth'); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
  <?php echo csrf_field(); ?>
  <div class="row">
      <div class="col-md-6 mb-4">
          <!-- Simple Tables -->
          <div class="card">           
        
              <div class="card-body">                  
                    <div class="form-group">
                      <label>Name</label>
                      <input value="<?php echo e(request('name')); ?>" name="name" type="text" class="form-control" placeholder="Enter bandwidth name" required>
                    </div>
                    <div class="form-group">                    
                      <div class="row">
                        <div class="col-8">
                          <label>Download Rate</label>
                          <input value="<?php echo e(request('rate_down')); ?>" name="rate_down" type="number" class="form-control" placeholder="Enter down rate" required>
                        </div>
                        <div class="col-4">
                        <label>Unit</label>
                          <select class="form-control"  name="rate_down_unit" required>
                            <option value="Kbps" <?php echo e(request('rate_down_unit')=='Kbps'?'selected':''); ?>>Kbps</option>
                            <option value="Mbps" <?php echo e(request('rate_down_unit')=='Mbps'?'selected':''); ?>>Mbps</option>
                          </select>
                        </div>
                      </div>                    
                    </div>                    

                    <div class="form-group">                    
                      <div class="row">
                        <div class="col-8">
                          <label>Up Rate</label>
                          <input value="<?php echo e(request('rate_up')); ?>" name="rate_up" type="number" class="form-control" placeholder="Enter down rate" required>
                        </div>
                        <div class="col-4">
                        <label>Unit</label>
                          <select class="form-control"  name="rate_up_unit" required>
                            <option value="Kbps" <?php echo e(request('rate_up_unit')=='Kbps'?'selected':''); ?>>Kbps</option>
                            <option value="Mbps" <?php echo e(request('rate_up_unit')=='Mbps'?'selected':''); ?>>Mbps</option>
                          </select>
                        </div>
                      </div>
                    
                    </div>
                    
                    <br>
                    <div class="form-group text-center">
                      <button type="submit" class="btn btn-primary pull-right mr-3">Create</button>
                      <a href="<?php echo e(url('admin/bandwidths')); ?>" class="btn btn-default pull-right">Back</a>
                    </div>
                    
              </div>        
              
          </div>
      </div>    
  </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/bandwidth/add.blade.php ENDPATH**/ ?>