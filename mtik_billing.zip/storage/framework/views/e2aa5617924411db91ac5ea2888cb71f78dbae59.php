    <!-- Scroll to top -->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <form method="post">
          <?php echo csrf_field(); ?>
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="id">
              Are you sure to delete?
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Confirm</button>
            </div>
          </div>
        </form>
      </div>
    </div>
    

    <?php $version = env('APP_VERSION'); ?>
    <script src="<?php echo e(asset('resources/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>?ver=<?php echo e($version); ?>"></script>
    <script src="<?php echo e(asset('resources/assets/js/theme.js')); ?>?ver=<?php echo e($version); ?>"></script>
    <script src="<?php echo e(asset('resources/assets/js/main.js')); ?>?ver=<?php echo e($version); ?>"></script>

    <?php echo $__env->yieldContent('bottomScripts'); ?>

  </body>

</html><?php /**PATH /var/www/html/mtik_billing/resources/views/layouts/main/footer.blade.php ENDPATH**/ ?>