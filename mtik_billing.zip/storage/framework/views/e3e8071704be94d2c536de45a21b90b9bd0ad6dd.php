<?php $__env->startSection('pageTitle', 'All Permissions'); ?>
<?php $__env->startSection('headerRight'); ?>
<form class="form-inline ml-auto ng-pristine ng-valid" method="get" action="">
    <div class="md-form my-0 mr-2">
        <select id="User Type" name="role_id" class="form-control form-control-sm">
            <option value="">Select Role</option>
            <?php $sel_role_id = isset($_GET['role_id'])?$_GET['role_id']:''; ?>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role->id); ?>" <?php echo e($sel_role_id==$role->id?'selected':''); ?>><?php echo e($role->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button href="#" class="btn btn-sm btn-primary btn-md my-0 ml-sm-2" type="submit"><i class="fa fa-search"></i></button>
    <a href="<?php echo e(url('admin/permissions/refresh')); ?>" class="btn btn-sm btn-default btn-md my-0 ml-sm-2" type="submit"><i class="fa fa-search"></i> Refresh</a>

</form>
<?php $__env->stopSection(); ?>

<?php
function check_permission_role($permission_id, $role_id, $pr){
    foreach($pr as $k){
        if($k->role_id == $role_id && $k->permission_id==$permission_id){
            echo 'checked';break;
        }
    }
}
?>
<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(url('admin/permissions/delete-assign')); ?>">
    <input type="hidden" name="role_id" value="<?php echo e($sel_role_id); ?>"/>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-12 mb-4">
            <!-- Simple Tables -->
            <div class="card">            
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mb-2">
                            <div>
                            <input type="checkbox" id="permission[<?php echo e($permission->id); ?>]" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php echo e(check_permission_role($permission->id, $sel_role_id,$permission_roles)); ?>>
                            <label for="permission[<?php echo e($permission->id); ?>]"><?php echo e($permission->name); ?></label>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>           
                <div class="card-footer" style="border-top:1px solid gainsboro;">
                   <div class="row">
                        <div class="col-md-3">
                            <select name="action" class="form-control form-control-sm" required>
                                    <option value=''>Select Action</option>
                                    <option value="1">Delete</option>
                                    <option value="2">Assign to Role</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button href="#" class="btn btn-sm btn-default btn-md my-0 ml-sm-2" type="submit">Confirm</button>
                        </div>
                   </div>
                </div>
            </div>        
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/permission/list.blade.php ENDPATH**/ ?>