 
<?php $__env->startSection('pageTitle', 'Edit Transaction : '.$data->id); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
	<?php echo csrf_field(); ?>
	<div class="row">
	
		<div class="col-md-6 mb-4">
			<!-- Simple Tables -->
			<div class="card">

				<div class="card-body">					
					
					<div class="table-responsive">
                        <table class="table table-td-sm table-bordered">  
                            <tbody>
                            	<tr><td>ID</td><td><?php echo e($data->id); ?></td><tr>
                            	<tr><td>Username</td><td><?php echo e($data->username); ?></td><tr>
                            	<tr><td>Plan</td><td><?php echo e($data->plan_name); ?></td><tr>  
                            	<tr><td>Amount</td><td><?php echo e($data->amount); ?></td><tr>  
                            	<tr><td>Method</td><td><?php echo e(ucwords($data->p_method)); ?></td><tr>  
                            	<tr><td>Trx ID</td><td><?php echo e($data->p_trxid); ?></td><tr>                         	
                            	<tr><td>Date</td><td><?php echo e($data->created_at->format('Y-m-d')); ?></td><tr>
                            	<tr>
                            		<td>Status</td>
                            		<td>
                            		<select class="form-control" name="status" required>
            							<option value="pending" <?php echo e($data->status=='pending'?'selected':''); ?>>Pending</option>
            							<option value="complete" <?php echo e($data->status=='complete'?'selected':''); ?>>Complete</option>
            						</select>
                            		</td>
								<tr>
                            </tbody>
                        </table>
                        
                        <br>
                        <br>

					<div class="form-group text-center">
						<button type="submit" class="btn btn-primary pull-right mr-3">Update</button>
		
					</div>

				</div>

			</div>
		</div>
	</div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/transaction/edit.blade.php ENDPATH**/ ?>