 
<?php $__env->startSection('pageTitle', 'Recharge'); ?>

<?php $__env->startSection('topScripts'); ?>
  <link href="<?php echo e(asset('resources/assets/vendor/select2/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="post">
	<input type="hidden" name="action" value="review">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col-md-6 mb-4">
			<!-- Simple Tables -->
			<div class="card">

				<div class="card-body">	
				
					<div class="form-group">
                        <label for="exampleFormControlSelect1">Customer</label>
                        <select class="form-control select2-single"  name="user_id" required>
                        <option value="">Select Customer</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" ><?php echo e($user->username); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>				
					
					<div class="form-group">
						<label for="exampleFormControlSelect1">Router</label> 
						<select id="select-router-for-plans" class="form-control" name="router_id" required>
							<option value="">Select Router</option> <?php $__currentLoopData = $routers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $router): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($router->id); ?>"><?php echo e($router->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					
					<div class="form-group">
						<label for="exampleFormControlSelect1">Plan</label> 
						<select id="load-plans-by-router" class="form-control" name="plan_id" required>
							<option value="">Select Plan</option>
						</select>
					</div>				

					<br>
					<div class="form-group text-center">
						<button type="submit" class="btn btn-primary pull-right mr-3">Recharge</button>
						<a href="<?php echo e(url('admin/prepaids')); ?>"
							class="btn btn-default pull-right">Back</a>
					</div>

				</div>

			</div>
		</div>
	</div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomScripts'); ?>
    <script src="<?php echo e(asset('resources/assets/vendor/select2/select2.min.js')); ?>"></script>
    <script>
    $('.select2-single').select2();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/prepaid/recharge.blade.php ENDPATH**/ ?>