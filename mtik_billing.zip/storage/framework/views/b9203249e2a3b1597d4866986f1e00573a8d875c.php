 <?php $__env->startSection('pageTitle', 'All Roles'); ?>

<?php $__env->startSection('headerRight'); ?>
<a class="btn btn-sm btn-primary btn-md my-0 ml-sm-2"
	href="<?php echo e(url('admin/roles/add')); ?>"><i class="fas fa-plus"></i> Add New</a>
<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12 mb-4">
		<!-- Simple Tables -->
		<div class="card">
			<div class="table-responsive">
				<table class="table align-items-center table-flush table-td-sm">
					<thead class="thead-light">
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>Type</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($role->id); ?></td>
							<td><?php echo e($role->name); ?></td>
							<td><?php echo e($role->slug); ?></td>
							<td><a href="<?php echo e(url("admin/roles/edit").'/'.$role->id); ?>"
									class="btn btn-sm btn-warning">Edit</a> <a d_id="<?php echo e($role->id); ?>"
								d_action="<?php echo e(url('/admin/roles/delete/'.$role->id)); ?>" href="#"
								class="btn btn-sm btn-danger delete-action-btn">Delete</a></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
			<div class="card-footer"></div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mtik_billing/resources/views/admin/role/index.blade.php ENDPATH**/ ?>