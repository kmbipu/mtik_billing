<?php echo $__env->make('layouts.main.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="wrapper">

    <?php echo $__env->make('layouts.main.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="content-wrapper" class="d-flex flex-column" >

      <div id="content">

        <?php echo $__env->make('layouts.main.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper" >

            <div class="d-sm-flex align-items-center justify-content-between mb-4" style="border-bottom: 1px solid gainsboro;padding: 0 0 10px 0;">
                <h4><?php echo $__env->yieldContent('pageTitle'); ?></h4>
                <ol class="breadcrumb mb-0" style="padding:0">
                  <?php echo $__env->yieldContent('headerRight'); ?>
              </ol>          
            </div>
            <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!---Container Fluid-->

      </div>

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; 2020 - Developed by
              <b><a href="http://codexwp.com" target="_blank">CodexWP</a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->

    </div>
  </div>

<?php echo $__env->make('layouts.main.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /var/www/html/mtik_billing/resources/views/layouts/main.blade.php ENDPATH**/ ?>